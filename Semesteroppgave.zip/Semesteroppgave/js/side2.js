var toaletter = [];

var parset;

function urlHandler(url){
  return new Promise(function(resolve,reject){
    var tempel = new XMLHttpRequest();
    tempel.open("GET", url)
    tempel.onreadystatechange = function(){
      if (tempel.readyState === 4){
        if (tempel.status === 200) {
        resolve(tempel.responseText);
      } else {
        reject(null);
      }
    };
  }
    tempel.send();
  });
}

function hentToalett() {
  var listen;
  var urlen = "https://hotell.difi.no/api/json/bergen/dokart?";
  var verdi = urlHandler(urlen);
  verdi.then(JSON.parse)
  .then(function(value){
    listen = value.entries;
    for(var i = 0; i < listen.length;i++){
      toaletter.push(listen[i]);
    }
    emptyValues();
    splitToalett();
    ordListeSjekk();
  });
  listeVisning(toaletter);
}

// HER KOMMER SØKET
function SearchCriteria (){
  this.freetext = "";
  this.gender = undefined;
  this.handicap = undefined;
  this.openNow = undefined;
  this.open = undefined;
  this.nursery = undefined;
  this.maxPrice = undefined;
  this.free = undefined;
}

/** En funksjon som går inn i et SearchCriteria-objekt og filtrerer toalett
 * i den globale toalettlisten som ikke er i samsvar med brukerens søk.
 */
function sjekk(element) {
  var listen = toaletter;
  if(crit.freetext){
    listen = listen.filter(toalett =>
    ((toalett.plassering.includes(crit.freetext))
    ||(toalett.place.includes(crit.freetext))
    ||(toalett.adresse.includes(crit.freetext))));
  }
  if(crit.gender){
    if(crit.gender == "man"||"male"||"mann"||"menn"||"herre"){
    listen = listen.filter(toalett => toalett.herre != "NULL");
    }
  }
  if(crit.gender){
    if(crit.gender == "female"||"ladies"||"woman"||"kvinne"||"dame"){
    listen = listen.filter(toalett => toalett.dame != "NULL");
    }
  }
  if(crit.gender){
    if(crit.gender == "male & female")
    listen = listen.filter(toalett => toalett.dame != "NULL" && toalett.herre != "NULL");
  }
  if(crit.openNow){
    listen = tidsFiltrering();
  }
  if(crit.open){
    listen = openWhen();
  }
  if(crit.handicap){
    listen = listen.filter(toalett => toalett.rullestol != "NULL");
  }
  if(crit.nursery){
    listen = listen.filter(toalett => toalett.stellerom != "NULL");
  }
  if(crit.free){
    listen = listen.filter(toalett => Number(toalett.pris) === 0);
  }
  if(crit.maxPrice){
    listen = listen.filter(toalett => Number(toalett.pris) <= Number(crit.maxPrice));
  }
  reduserListe(listen);
  listeVisning(listen);
}

/**
 * emptyValues er en funksjon som går gjennom toalettlisten
 * og endrer verdiene i de forskjellige feltene slik at de
 * har samme variabel-typer (int/string)
 */
function emptyValues(){
  for(i = 0; i < toaletter.length; i++){
    if(toaletter[i].pris == "NULL"){
      toaletter[i].pris = "0";
    }
    if(toaletter[i].herre.length == 0){
      toaletter[i].herre.length = "NULL"
    }
    if(toaletter[i].dame.length == 0){
      toaletter[i].dame.length = "NULL"
    }
    if(toaletter[i].pissoir_only.length == 0){
      toaletter[i].pissoir_only.length = "NULL"
    }
    if(toaletter[i].stellerom.length == 0){
      toaletter[i].stellerom = "NULL";
    }
    if(toaletter[i].rullestol.length == 0){
      toaletter[i].rullestol = "NULL";
    }
  }
}

/**
 * En funksjon som går inn i feltene plassering, place og adresse i den
 * globale toalettlisten. Her splitter funksjonen alle feltverdier som har mellomrom
 * og returnere enkeltordene tilbake i feltene, men nå i form av lister.
 * Ordene i listene blir også gjort om til små bokstaver.
 */
function splitToalett(){
  for(i = 0; i < toaletter.length; i++){
    toaletter[i].plassering = toaletter[i].plassering.toLowerCase();
    toaletter[i].adresse = toaletter[i].adresse.toLowerCase();
    toaletter[i].place = toaletter[i].place.toLowerCase();

    toaletter[i].plassering = toaletter[i].plassering.split(" ");
    toaletter[i].adresse = toaletter[i].adresse.split(" ");
    toaletter[i].place = toaletter[i].place.split(" ");

    if(toaletter[i].plassering.length > 1){
      var str = "";
      str = toaletter[i].plassering.join(" ");
      toaletter[i].plassering.push(str);
    }
    if(toaletter[i].adresse.length > 1){
      var str = "";
      str = toaletter[i].adresse.join(" ");
      toaletter[i].adresse.push(str);
    }
    if(toaletter[i].place.length > 1){
      var str = "";
      str = toaletter[i].place.join(" ");
      toaletter[i].place.push(str);
    }
  }
  return toaletter;
}

/**
 * En funksjon som går gjennom feltene place, addresse og
 * plassering i toalettlisten, og ser til at ordene ikke inneholder
 * komma, unødvendige mellomrom og enestående nummer.
 */
function ordListeSjekk() {
  var kommaRegExp = /^,$/g;
  var kommaRegExp1 = /,$/g;
  var kommaRegExp2 = / , /g;
  var kommaRegExp3 = /, /g;

  for(i = 0; i < toaletter.length; i++){
    for(x = 0; x < toaletter[i].plassering.length; x++){
      if(toaletter[i].plassering[x].match(kommaRegExp)){
        toaletter[i].plassering.splice(x, 1);
      }
      if(toaletter[i].plassering[x].match(kommaRegExp1)){
        toaletter[i].plassering[x] = toaletter[i].plassering[x].replace(kommaRegExp1, "");
      }
      if(toaletter[i].plassering[x].match(kommaRegExp2)){
        toaletter[i].plassering[x] = toaletter[i].plassering[x].replace(kommaRegExp2, " ");
      }
      if(toaletter[i].plassering[x].match(kommaRegExp3)){
        toaletter[i].plassering[x] = toaletter[i].plassering[x].replace(kommaRegExp3, " ");
      }
    }
  }
  for(i = 0; i < toaletter.length; i++){
    for(x = 0; x < toaletter[i].place.length; x++){
      if(toaletter[i].place[x].match(kommaRegExp)){
         toaletter[i].place.splice(x, 1);
      }
      if(toaletter[i].place[x].match(kommaRegExp1)){
        toaletter[i].place[x] = toaletter[i].place[x].replace(kommaRegExp1, "");
      }
      if(toaletter[i].place[x].match(kommaRegExp2)){
        toaletter[i].place[x] = toaletter[i].place[x].replace(kommaRegExp2, " ");
      }
      if(toaletter[i].place[x].match(kommaRegExp3)){
        toaletter[i].place[x] = toaletter[i].place[x].replace(kommaRegExp3, " ");
      }
    }
  }
  for(i = 0; i < toaletter.length; i++){
    for(x = 0; x < toaletter[i].adresse.length; x++){
      if(toaletter[i].adresse[x].match(kommaRegExp)){
         toaletter[i].adresse.splice(x, 1);
      }
      if(toaletter[i].adresse[x].match(kommaRegExp1)){
        toaletter[i].adresse[x] = toaletter[i].adresse[x].replace(kommaRegExp1, "");
      }
      if(toaletter[i].adresse[x].match(kommaRegExp2)){
        toaletter[i].adresse[x] = toaletter[i].adresse[x].replace(kommaRegExp2, " ");
      }
      if(toaletter[i].adresse[x].match(kommaRegExp3)){
        toaletter[i].adresse[x] = toaletter[i].adresse[x].replace(kommaRegExp3, " ");
      }
      if(toaletter[i].adresse[x].match(/^\d+$/g)){
        toaletter[i].adresse.splice(x,1);
      }
    }
  }
}

/**
 * Denne funksjonen sjekker tilstanden til de forskjellige checkboxene
 * i den avanserte søkefunksjonnen, og endrer feltene til søkeobjektet
 * basert på avhukingen.
 */
SearchCriteria.prototype.setBox = function() {
  var male = (document.getElementById("male").checked);
  var female = (document.getElementById("female").checked);
  var handicap = (document.getElementById("handicap").checked);
  var openNow = (document.getElementById("openNow").checked);
  var open = (document.getElementById("open").value);
  var nursery = (document.getElementById("nursery").checked);
  var free = (document.getElementById("free").checked);
  var maxPrice = (document.getElementById("maxPrice").value);

  if(male && !female) {
    this.gender = "male";
  }
  if(female && !male) {
    this.gender = "female";
  }
  if(male && female){
    this.gender = "male & female"
  }
  if(handicap) {
    this.handicap = "On"
  }
  if(openNow) {
    this.openNow = "On"
  }
  if(open != "") {
    if(open.match(this.openRegExp)){
      this.open = open;
    }
  }
  if(nursery) {
    this.nursery = "On"
  }
  if(free) {
    this.free = "On"
  }
  if(maxPrice != ""){
    if(maxPrice.match(/(\d+)/)){
      this.maxPrice = maxPrice;
    }
  }
}


/**
 * Lager en utvidelse av searchCriteria, som er en funskjon
 * som går gjennom teksten skrevet i søkefeltet og sjekker
 * om den matcher med regExp uttrykkene satt for de forskjellige søkeverdiene.
 * Hvis teksten matcher, endrer den tilstanden til søkeobjektet.
 */
SearchCriteria.prototype.setText = function (text) {
  var genderMatch = text.match(this.genderRegExp);
  var handicapMatch = text.match(this.handicapRegExp);
  var openNowMatch = text.match(this.openNowRegExp);
  var openMatch = text.match(this.openRegExp);
  var nurseryMatch = text.match(this.nurseryRegExp);
  var maxPriceMatch = text.match(this.maxPriceRegExp);
  var freeMatch = text.match(this.freeRegExp);
  var freeTextMatch = text.match(this.freeTextRegExp)

  if(genderMatch){
    this.gender = genderMatch[0];
    text = text.replace(this.genderRegExp, "");
  } else {
    this.gender = undefined;
  }

    if(handicapMatch){
    this.handicap = "On";
    text = text.replace(this.handicapRegExp, "");
  } else {
    this.handicap = undefined;
  }

    if(openNowMatch){
    this.openNow = "On";
    text = text.replace(this.openNowRegExp, "");
  } else {
    this.open = undefined;
  }

    if(openMatch){
    this.open = openMatch[0];
    text = text.replace(this.openRegExp, "");
  } else {
    this.open = undefined;
  }

    if(nurseryMatch){
    this.nursery = "On";
    text = text.replace(this.nurseryRegExp, "");
  } else {
    this.nursery = undefined;
  }

    if(maxPriceMatch){
    this.maxPrice = maxPriceMatch[1];
    text = text.replace(this.maxPriceRegExp, "");
  } else {
    this.maxPrice = undefined;
  }

    if(freeMatch){
    this.free = "On";
    text = text.replace(this.freeRegExp, "");
  } else {
    this.free = undefined;
  }

    if(freeTextMatch){
    this.freetext = text.trim();
  }
    else {
    this.freetext = text;
  }
}
/**
* Forskjellige regExp-uttrykk for de forskjellige feltene til SearchCriteria-objektet
*/
SearchCriteria.prototype.genderRegExp = /(mann|male|man|herre|female|woman|ladies|kvinne|dame)/;
SearchCriteria.prototype.handicapRegExp = /(rullestol|hc|wheelchair|handicap)/;
SearchCriteria.prototype.openNowRegExp = /(openNow|åpenNå)/;
SearchCriteria.prototype.openRegExp = /(\d\d(\.|\:|)\d\d)/;
SearchCriteria.prototype.nurseryRegExp = /(stellerom|nursery)/;
SearchCriteria.prototype.maxPriceRegExp = /maxPrice:(\d+)/;
SearchCriteria.prototype.freeRegExp = /(gratis|free)/;
SearchCriteria.prototype.freeTextRegExp = /^(\s+)?((\w+|\W+)+)?(\s+)?$/g;

var crit = new SearchCriteria();

/**
 * En funskjon som initierer setText- og setBox-funksjonene i søkeobjektet
 * vårt. Funksjonen "scanner" både søkefeltet og det avanserte søket
 * i html-filen og skriver ut søkeobjektet på en lett leselig måte i konsollen.
 */
function scan() {
  crit.setText(document.getElementById("search").value);
  crit.setBox();
  console.log(crit);
}

// SØK SLUTTER


var markers = [];


function listeVisning(liste){
  var tjohei = document.getElementById("smør");
  tjohei.innerHTML = "";
  var i = 0;
  liste.forEach(function(toalett) {
  i++;
  tjohei.innerHTML += "<li>" + "<a id='toalettlenke' onclick='klikkern(" + (i) + ")'>" + toalett.place[toalett.place.length - 1] + "</a></li>" + ("</br>");
});
}


/**
* En funksjon som utføres når nettsiden starter.
*/
function launch(){
  hentToalett();
  startTime();
  hamburger();
 setTimeout(function(){listeVisning(toaletter);sjekk();},200);
 // venter på at HTTP-forespørselen går igjennom før den kjører listevisningen
}

window.onload = launch();

function initMap() {
  var infowindow = new google.maps.InfoWindow();
  var bergen = {lat: 60.392209, lng: 5.324011};
  var map = new google.maps.Map(document.getElementById('googlemap'), {
    zoom: 13,
    center: bergen
  });
  infoWindow = new google.maps.InfoWindow;


  for(var i = 0; i < toaletter.length; i++){
      var latLng = new google.maps.LatLng(toaletter[i].latitude, toaletter[i].longitude);
      var contentString = toaletter[i].id + ". " + toaletter[i].place[toaletter[i].place.length -1]

      marker = new google.maps.Marker({
            position: latLng,
            label: toaletter[i].id,
            map: map,
            contentString: contentString
      });

      marker.addListener('click', function() {
             infowindow.setContent(this.contentString);
             infowindow.open(map, this);
             map.setCenter(this.getPosition());
       });
           markers.push(marker);
  }
}
// Benytter seg av Markers arrayet for å kunne referere til spesifikke iWindows
function klikkern(i){
  google.maps.event.trigger(markers[i-1], 'click');
}


// Viser/skjuler avanserte valg for søk
function visAvansert(){
  var innholdet = document.getElementById("toggle");
  if(innholdet.style.display === "none"){
    innholdet.style.display = "flex";
    }
      else {
        innholdet.style.display = "none";
      }
}

 //Klokke Under kopiert fra W3Schools
 function startTime() {
    var today = new Date();
    var h = today.getHours();
    var m = today.getMinutes();
    var s = today.getSeconds();
    m = checkTime(m);
    s = checkTime(s);
    document.getElementById('txt').innerHTML =
    h + ":" + m;
    var t = setTimeout(startTime, 500);
}
function checkTime(i) {
    if (i < 10) {i = "0" + i};
    return i;
}

//  Logger ut og returnerer tiden. Filter for alternativ tidsvisning.
function getTime(){
  var filteret = /(\d\d)(:)(\d\d)(:)(\d\d)?/;
  var tiden = document.getElementById('txt').innerHTML;
  return tiden;
}

//Finner ukedagstallet og setter verdi av uke/lør/søn. Brukes i tidssøk.
function dagen() {
    var d = new Date();
    var n = d.getDay()
    var x;
    if(n > 0 && n <=5){
      x = "uke";
    }
    if(n == 6) {
      x = "lør";
    }
    if(n == 0) {
      x = "søn";
    }
    return x;
}



//reduserListe() kalles av alle søkefunksjoner, og tømmer markerlista for så å fylle den opp med de nye resultatene
function reduserListe(list){
  markers = [];
  var listen = list;
  var infowindow = new google.maps.InfoWindow();
  var bergen = {lat: 60.392209, lng: 5.324011};
  var map = new google.maps.Map(document.getElementById('googlemap'), {
    zoom: 13,
    center: bergen
  });
  infoWindow = new google.maps.InfoWindow;
  for(var i = 0; i < listen.length; i++){
      var latLng = new google.maps.LatLng(listen[i].latitude, listen[i].longitude);
      var contentString = ("<h4>" + (i+1) + ". " + listen[i].place[listen[i].place.length -1] + "</h4>"
      + "hverdag: " + listen[i].tid_hverdag
      + "</br>" + "lørdag: " + listen[i].tid_lordag
      + "</br>" + "søndag: " + listen[i].tid_sondag);

      marker = new google.maps.Marker({
            position: latLng,
            label: (i+1).toString(),
            map: map,
            contentString: contentString
      });




      marker.addListener('click', function() {
             infowindow.setContent(this.contentString);
             infowindow.open(map, this);
             map.setCenter(this.getPosition());
       });
           markers.push(marker);
  }
}



// Henter nåtid og returnerer det som en tallvariabel. Brukes av tidsfiltrering(). -Odin
function tiden(){
  var tidspunkt = Number(getTime().replace(/(\:|\.)/g,""));
  return tidspunkt;
  }

/**
 * Henter ut ukens dag, og basert på resultatet looper igjennom toalettlisten,
 * og sjekker om verdien for åpningstiden er større enn nåtid. Hvis ja, push til lista[],
 * som igjen brukes av sjekk()  -Odin
 */
function tidsFiltrering(){
  var lista = [];
  var x = filterFix();
  var tidspunkt = tiden();
  var toalettet;
  var kriteriet = /(\d\d)\.(\d\d)\s\-\s(\d\d)\.(\d\d)/;
  var toanTest;

  for (var i = 0; i < toaletter.length; i++) {
    if (toaletter[i][x] != "NULL"){// kriterie: åpningstiden er ikke NULL/stengt
      if(toaletter[i][x] == "ALL"){// Kriterie: Åpningstiden er ALL/døgnåpen
        lista.push(toaletter[i]);
      }
      else { //Hvis ikke døgnåpen eller stengt, sjekk siste time+minutt mot nåtid time+minutt
        toalettet = toaletter[i][x];
        toan = kriteriet.exec(toalettet);
        toanTest = Number(toan[3]+toan[4]);
        if(toanTest >= tidspunkt){
          lista.push(toaletter[i]);
          }
      }
      }
    }
    return lista;
  }

/**
 * Via dagen() får vi en verdi som gjøres om til en matchende string for variabel-navnene i toaletter[].
 * Egentlig overflødig, ettersom dagen() kunne ha hatt det, men skal brukes til andre ting også.
 */
function filterFix(){
  var uke = dagen();
  var listeKriteriet;
      if(uke == "uke"){
        listeKriteriet = "tid_hverdag";
      }
      else if (uke == "lør") {
        listeKriteriet = "tid_lordag";
      }
      else if (uke == "søn") {
        listeKriteriet = "tid_sondag";
      }
  return listeKriteriet;
}

function openWhen(){
  var x = filterFix();
  var kriteriet = /(\d\d)\.(\d\d)\s\-\s(\d\d)\.(\d\d)/;
  var lista = [];
  var tidspunkt = Number(crit.open.replace(/(\.|\s|\:)/,""));

  for (var i = 0; i < toaletter.length; i++) {
      if (toaletter[i][x] != "NULL"){// kriterie: åpningstiden er ikke NULL/stengt
        if(toaletter[i][x] == "ALL"){// Kriterie: Åpningstiden er ALL/døgnåpen
          lista.push(toaletter[i]);
        }
        else { //Hvis ikke døgnåpen eller stengt, sjekk siste time+minutt mot nåtid time+minutt
          toalettet = toaletter[i][x];
          toan = kriteriet.exec(toalettet);
          toanMin = Number(toan[1]+toan[2]);
          toanMax = Number(toan[3]+toan[4]);
          if(toanMin <= tidspunkt && tidspunkt < toanMax){
            lista.push(toaletter[i]);
          }
        }
      }
    }
    return lista;
}

/**
* En funksjon som endrer display-tistanden til hamburger-menyen,
* når den blir klikket på.
*/
function hamburger(){
  var x = document.getElementById("li");
  if(x.style.display === "none"){
    x.style.display = "block";
  } else {
    x.style.display = "none";
  }
}

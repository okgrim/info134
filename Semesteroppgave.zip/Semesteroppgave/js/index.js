/*
* En funksjon som endrer display-tistanden til hamburger-menyen,
* når den blir klikket på.
*/
function hamburger(){
  var x = document.getElementById("li");
  if(x.style.display === "none"){
    x.style.display = "block";
  } else {
    x.style.display = "none";
  }
}

/*
* En funksjon som utføres når nettsiden starter.
*/
function launch(){
  hamburger();
}
window.onload = launch();
